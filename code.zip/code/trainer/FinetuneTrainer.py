import pandas as pd
from .BaseTrainer import BaseTrainer
import numpy as np
import torch
import time
from utils.loss import patchify
import os
from tqdm import tqdm

# [WANDB] optional import
try:
    import wandb

    _WANDB_AVAILABLE = True
except Exception:
    wandb = None
    _WANDB_AVAILABLE = False
import torch.nn.functional as F

def _masked_ce_from_logits(logits, target_ids, target_masks):
    """
    logits: [B, L, V]
    target_ids: [B, L]
    target_masks: [B, L]
    """
    if isinstance(logits, (tuple, list)):
        logits = logits[0]
    vocab_size = logits.size(-1)
    loss = F.cross_entropy(
        logits.reshape(-1, vocab_size),
        target_ids.reshape(-1),
        reduction='none'
    ).reshape_as(target_ids).float()
    mask = target_masks.float()
    return (loss * mask).sum() / (mask.sum() + 1e-8)


def _token_set_f1(pred_text, gt_text):
    pred_set = set(pred_text.split())
    gt_set = set(gt_text.split())

    if len(pred_set) == 0 and len(gt_set) == 0:
        return 1.0
    if len(pred_set) == 0 or len(gt_set) == 0:
        return 0.0

    inter = len(pred_set & gt_set)
    precision = inter / (len(pred_set) + 1e-8)
    recall = inter / (len(gt_set) + 1e-8)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


class Trainer(BaseTrainer):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader, val_dataloader,
                 test_dataloader):
        super(Trainer, self).__init__(model, criterion, metric_ftns, optimizer, args)
        self.lr_scheduler = lr_scheduler
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader
        self.best_score = 0.

        # Load pretrained model if specified (usually for initialization)
        if args.get("load_model_path", ""):
            print(f"Loading pretrained model from {args['load_model_path']}")
            try:
                state = torch.load(args["load_model_path"], map_location='cuda')
                if 'state_dict' in state:
                    self.model.load_state_dict(state['state_dict'], strict=False)
                else:
                    self.model.load_state_dict(state, strict=False)
            except Exception as e:
                print(f"Warning: Failed to load pretrained model: {e}")

    def _train_epoch(self, epoch):
        # ---------------------------------------------------------
        # 1. Training Phase
        # ---------------------------------------------------------
        train_loss = 0
        self.model.train()

        pbar = tqdm(enumerate(self.train_dataloader), total=len(self.train_dataloader), desc=f"Epoch {epoch} Training")

        for batch_idx, (images_id, images, reports_ids, reports_masks) in pbar:
            images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()

            self.optimizer.zero_grad()

            # Forward (train)
            output = self.model(images, reports_ids, mode='train', epoch=epoch, sample_ids=images_id, split='train')

            # Original training loss
            loss = self.criterion(output, reports_ids, reports_masks)
            loss.backward()

            torch.nn.utils.clip_grad_value_(self.model.parameters(), 0.1)
            self.optimizer.step()

            train_loss += loss.item()
            pbar.set_postfix({'loss': loss.item()})

        log = {'train_loss': train_loss / len(self.train_dataloader)}

        # ---------------------------------------------------------
        # 2. Validation Phase
        # ---------------------------------------------------------
        self.model.eval()
        with torch.no_grad():
            val_gts, val_res = [], []
            val_ce_sum, val_ce_cnt = 0.0, 0
            val_f1_list = []

            val_pbar = tqdm(enumerate(self.val_dataloader), total=len(self.val_dataloader),
                            desc=f"Epoch {epoch} Validation")

            for batch_idx, (images_id, images, reports_ids, reports_masks) in val_pbar:
                images = images.cuda()
                reports_ids = reports_ids.cuda()
                reports_masks = reports_masks.cuda()

                # (A) Beam search generation (original logic)
                output = self.model(images, mode='sample', sample_ids=images_id, split='val')
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())

                val_res.extend(reports)
                val_gts.extend(ground_truths)

                # (B) CE on val (teacher-forcing)
                tf_logits = self.model(images, reports_ids, mode='train', epoch=epoch, sample_ids=images_id,
                                       split='val')
                ce = _masked_ce_from_logits(tf_logits, reports_ids, reports_masks)
                val_ce_sum += ce.item()
                val_ce_cnt += 1

                # (C) F1 on generated text
                for pred, gt in zip(reports, ground_truths):
                    val_f1_list.append(_token_set_f1(pred, gt))

            # Existing text generation metrics
            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})
            log.update(**{'val_' + k: v for k, v in val_met.items()})

            # Added CE/F1
            log['val_CE'] = val_ce_sum / max(val_ce_cnt, 1)
            log['val_F1'] = float(np.mean(val_f1_list)) if len(val_f1_list) > 0 else 0.0

        # ---------------------------------------------------------
        # 3. Scheduler Step
        # ---------------------------------------------------------
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

        # ---------------------------------------------------------
        # 4. Test Phase
        # ---------------------------------------------------------
        if hasattr(self, 'test_dataloader') and self.test_dataloader is not None:
            self.model.eval()
            test_gts, test_res = [], []
            test_ce_sum, test_ce_cnt = 0.0, 0
            test_f1_list = []

            test_pbar = tqdm(enumerate(self.test_dataloader), total=len(self.test_dataloader),
                             desc=f"Epoch {epoch} Test")

            with torch.no_grad():
                for batch_idx, (images_id, images, reports_ids, reports_masks) in test_pbar:
                    images = images.cuda()
                    reports_ids = reports_ids.cuda()
                    reports_masks = reports_masks.cuda()

                    # (A) generation
                    output = self.model(images, mode='sample', sample_ids=images_id, split='test')
                    decoded_out = self.model.tokenizer.decode_batch(output.cpu().numpy())
                    decoded_gts = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())

                    test_res.extend(decoded_out)
                    test_gts.extend(decoded_gts)

                    # (B) CE
                    tf_logits = self.model(images, reports_ids, mode='train', epoch=epoch, sample_ids=images_id,
                                           split='test')
                    ce = _masked_ce_from_logits(tf_logits, reports_ids, reports_masks)
                    test_ce_sum += ce.item()
                    test_ce_cnt += 1

                    # (C) F1
                    for pred, gt in zip(decoded_out, decoded_gts):
                        test_f1_list.append(_token_set_f1(pred, gt))

                test_scores = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                               {i: [re] for i, re in enumerate(test_res)})

                for k, v in test_scores.items():
                    log[f'test_{k}'] = v

                log['test_CE'] = test_ce_sum / max(test_ce_cnt, 1)
                log['test_F1'] = float(np.mean(test_f1_list)) if len(test_f1_list) > 0 else 0.0

        return log