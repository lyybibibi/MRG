import torch
import torch.nn as nn
import torch.nn.functional as F


class RCSFilter(nn.Module):
    """
    自适应证据过滤 (Adaptive Context Selection)
    采用 MMed-RAG 的 Top-1 相对比率截断法，保障数值稳定性。
    """

    def __init__(self, temperature=0.1, retrieve_threshold=2.0):
        super().__init__()
        self.temperature = temperature
        self.retrieve_threshold = retrieve_threshold

    def forward(self, h_pooled, k_embs):
        # h_pooled: [B, D] - 去偏后的视觉特征
        # k_embs: [B, K, D] - 在线/离线检索到的知识特征

        h_norm = F.normalize(h_pooled, p=2, dim=-1)
        k_norm = F.normalize(k_embs, p=2, dim=-1)

        # 计算特征相似度
        sim = torch.bmm(k_norm, h_norm.unsqueeze(-1)).squeeze(-1)  # [B, K]

        # 转化为概率分布以避免负数与零除陷阱
        probs = torch.softmax(sim / self.temperature, dim=-1)
        sorted_probs, sorted_indices = torch.sort(probs, descending=True)

        # 锚定 Top-1，计算后续证据的比率骤降
        top1_prob = sorted_probs[:, 0:1]
        ratios = top1_prob / (sorted_probs + 1e-8)

        # 截断掩码 (True为保留，False为剔除长尾噪声)
        mask_sorted = ratios < self.retrieve_threshold

        # 将掩码还原回原始序列索引
        mask = torch.zeros_like(mask_sorted, dtype=torch.bool)
        mask.scatter_(1, sorted_indices, mask_sorted)

        return mask, sim


class VocabularyDebiasing(nn.Module):
    """
    分布偏置校准 (Distribution Bias Calibration)
    将过滤后的知识转化为语言概率空间的偏置项。
    """

    def __init__(self, embed_dim, vocab_size, dropout=0.1):
        super().__init__()
        self.evidence_to_vocab_bias = nn.Sequential(
            nn.Linear(embed_dim, embed_dim * 2),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(embed_dim * 2, vocab_size)
        )
        self.bias_gate = nn.Sequential(
            nn.Linear(embed_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, vocab_logits, evidence_pooled):
        # 1. 计算原始偏置
        raw_bias = self.evidence_to_vocab_bias(evidence_pooled)  # [B, Vocab]

        # 【提分核心修改】：用 Tanh 锁死偏置极值，防止数值膨胀
        # 乘以 3.0 意味着外部知识最多只能给某个词增加 3.0 的 Logit 优势
        vocab_bias = torch.tanh(raw_bias) * 3.0

        # 2. 计算门控并施加硬截断
        gate = self.bias_gate(evidence_pooled)  # [B, 1]
        gate = torch.clamp(gate, max=0.5)

        # 3. 维度安全的偏置注入
        bias_term = gate * vocab_bias  # [B, Vocab]

        if vocab_logits.dim() == 3:
            bias_term = bias_term.unsqueeze(1)  # 升维 [B, 1, Vocab]

        adjusted_logits = vocab_logits + bias_term
        return adjusted_logits