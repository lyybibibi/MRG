# modules/knowledge_retriever_radar.py
import json
import os
from typing import Dict, List, Any, Optional, Iterable, Tuple

import torch
import torch.nn as nn

try:
    import torch.distributed as dist
except Exception:
    dist = None
import torch
import torch.nn as nn
import torch.nn.functional as F


class OnlineCausalRetriever(nn.Module):
    def __init__(self, embed_dim, memory_size=2000, max_k=10, rcs_threshold=1.1):
        super(OnlineCausalRetriever, self).__init__()
        self.embed_dim = embed_dim
        self.max_k = max_k
        self.rcs_threshold = rcs_threshold  # 对应 MMed 的 retrieve_threshold

        # 外部知识库 (建议用真实报告的 CLIP/语言模型特征初始化)
        self.register_buffer('knowledge_bank', torch.randn(memory_size, embed_dim))

        # 检索投影层
        self.query_proj = nn.Linear(embed_dim, embed_dim)
        self.key_proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, h_debiased):
        """
        利用去偏特征 h_debiased 执行检索，并严格应用 MMed 的真实 RCS 策略
        """
        B = h_debiased.size(0)
        # 提取整图去偏语义
        h_query = h_debiased.mean(dim=1)  # [B, D]

        # 1. 计算在线 Logits (内积或缩放点积)
        q = F.normalize(self.query_proj(h_query), p=2, dim=-1)
        k_mem = F.normalize(self.key_proj(self.knowledge_bank), p=2, dim=-1)

        # [B, Memory_Size]
        logits = torch.einsum('bd, md -> bm', q, k_mem)
        # 为了防止负数导致 ratio 计算异常，可加入一个平滑项或确保 logits 为正（如缩放余弦相似度到 0~1）
        logits = (logits + 1.0) / 2.0

        # 2. 提取 Top-K 候选池 (防止在全库上操作，节省显存)
        topk_logits, topk_indices = torch.topk(logits, self.max_k, dim=-1)  # [B, max_k]

        # 获取锚点 (Top-1 Logit) -> [B, 1]
        top1_logits = topk_logits[:, :1]

        # 3. MMed 核心 RCS 逻辑复刻：计算 Ratio
        ratios = top1_logits / (topk_logits + 1e-8)

        # 构建有效知识的掩码 (Mask)：True 表示保留，False 表示截断
        # 维度: [B, max_k]
        valid_mask = ratios < self.rcs_threshold

        retrieved_k_list = []
        for i in range(B):
            # 获取当前样本的有效索引和 Logit
            mask_i = valid_mask[i]

            # 极端情况防跌落：如果全部被 mask 掉（理论上不可能，因为 top1 ratio 必为 1），强制保留 Top-1
            if not mask_i.any():
                mask_i[0] = True

            valid_idx = topk_indices[i][mask_i]  # [dynamic_k]
            valid_logits = topk_logits[i][mask_i]  # [dynamic_k]

            # 【关键】：可导的特征聚合
            # 将 Logits 转化为注意力权重 (Softmax)，这样知识的融合依然保留着梯度流
            attn_weights = F.softmax(valid_logits, dim=0).unsqueeze(-1)  # [dynamic_k, 1]

            # 根据索引拉取知识特征，并加权融合
            valid_knowledge = self.knowledge_bank[valid_idx]  # [dynamic_k, D]
            aggregated_k = (valid_knowledge * attn_weights).sum(dim=0)  # [D]

            retrieved_k_list.append(aggregated_k)

        return torch.stack(retrieved_k_list, dim=0)  # [B, D]
    
class RadarJsonlIndex(object):
    """Load RADAR retrieval jsonl: each line {"id":..., "retrieved":[...]}"""

    def __init__(self, jsonl_path: str):
        if not os.path.exists(jsonl_path):
            raise FileNotFoundError(f"[RadarJsonlIndex] jsonl not found: {jsonl_path}")
        self.jsonl_path = jsonl_path
        self.map: Dict[str, List[str]] = {}
        self._load()

    def _load(self) -> None:
        with open(self.jsonl_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                obj = json.loads(line)
                sid = str(obj.get("id"))
                retrieved = [str(x) for x in obj.get("retrieved", [])]
                self.map[sid] = retrieved

    def get(self, sample_id: str, topk: int) -> List[str]:
        ids = self.map.get(str(sample_id), [])
        return ids[: max(int(topk), 0)]


class AnnotationReportBank(object):
    """Map sample_id -> report/findings text from annotation.json.

    Supports common patterns:
      A) split lists: {"train":[...], "val":[...], "test":[...]}
      B) split dict-of-dicts: {"train": {sid: {...}, ...}, "val": {...}, "test": {...}}
      C) flat list: [{...}, ...]
      D) dict-of-dicts keyed by sample id: {sid: {...}, ...}
      E) {"annotations": [...]}
    """

    def __init__(self, ann_path: str):
        if not os.path.exists(ann_path):
            raise FileNotFoundError(f"[AnnotationReportBank] annotation not found: {ann_path}")
        self.ann_path = ann_path
        self.ann: Any = None
        self.id2report: Dict[str, str] = {}
        self._load()

    @staticmethod
    def _pick_report(obj: Dict[str, Any]) -> Optional[str]:
        # Prefer report (IU-Xray), then findings, impression, caption, text.
        for k in ["report", "findings", "impression", "caption", "text"]:
            if k in obj and isinstance(obj[k], str) and obj[k].strip():
                return obj[k].strip()

        # Some datasets store as list of sentences
        for k in ["report", "findings", "impression", "caption", "text"]:
            if k in obj and isinstance(obj[k], list) and obj[k]:
                parts = [str(x) for x in obj[k] if x is not None]
                s = " ".join(parts).strip()
                if s:
                    return s
        return None

    @staticmethod
    def _pick_id(obj: Dict[str, Any]) -> Optional[str]:
        for k in ["id", "image_id", "study_id", "uid"]:
            if k in obj and obj[k] is not None:
                return str(obj[k])
        return None

    def _iter_annotation_items(self, ann: Any) -> Iterable[Tuple[Optional[str], Dict[str, Any]]]:
        """Yield (sid, obj_dict) pairs from different annotation formats."""
        if isinstance(ann, list):
            for x in ann:
                if isinstance(x, dict):
                    sid = self._pick_id(x)
                    yield sid, x
            return

        if isinstance(ann, dict):
            # Format E: {"annotations": [...]}
            if "annotations" in ann and isinstance(ann["annotations"], list):
                for sid, obj in self._iter_annotation_items(ann["annotations"]):
                    yield sid, obj
                return

            # Format A/B: {"train": ..., "val": ..., "test": ...}
            if any(k in ann for k in ["train", "val", "test"]):
                for split_key in ["train", "val", "test"]:
                    if split_key not in ann:
                        continue
                    block = ann[split_key]
                    # A: split list
                    if isinstance(block, list):
                        for sid, obj in self._iter_annotation_items(block):
                            yield sid, obj
                    # B: split dict-of-dicts keyed by sid
                    elif isinstance(block, dict):
                        for sid_key, obj in block.items():
                            if isinstance(obj, dict):
                                sid = str(obj.get("id", sid_key))
                                yield sid, obj
                return

            # Format D: dict-of-dicts keyed by sid
            if all(isinstance(v, dict) for v in ann.values()):
                for sid_key, obj in ann.items():
                    if isinstance(obj, dict):
                        sid = str(obj.get("id", sid_key))
                        yield sid, obj
                return

        # Unknown format: yield nothing

    def _load(self) -> None:
        with open(self.ann_path, "r", encoding="utf-8") as f:
            self.ann = json.load(f)

        for sid, obj in self._iter_annotation_items(self.ann):
            if sid is None or not isinstance(obj, dict):
                continue
            rep = self._pick_report(obj)
            if rep is not None:
                self.id2report[str(sid)] = rep

    def get_report(self, rid: str) -> str:
        return self.id2report.get(str(rid), "")


class RadarKnowledgeRetriever(nn.Module):
    """Offline RADAR evidence retriever: jsonl -> retrieved ids -> reports -> encode to K [B, topk, D]."""

    def __init__(
        self,
        knowledge_jsonl_path: str,
        ann_path: str,
        text_embed: nn.Module,
        max_seq_length: int,
        pad_idx: int,
        topk: int = 4,
        debug: bool = False,
        debug_print_n: int = 1,
        debug_max_chars: int = 220,
    ):
        super().__init__()
        self.index = RadarJsonlIndex(knowledge_jsonl_path)
        self.bank = AnnotationReportBank(ann_path)

        self.text_embed = text_embed
        self.max_seq_length = int(max_seq_length)
        self.pad_idx = int(pad_idx)
        self.topk = int(topk)

        self.debug = bool(debug)
        self._debug_print_left = int(debug_print_n)
        self.debug_max_chars = int(debug_max_chars)

    def _encode_report_with_project_tokenizer(self, tokenizer, report_text: str, device: torch.device) -> torch.Tensor:
        if report_text is None:
            report_text = ""
        if hasattr(tokenizer, "encode"):
            ids = tokenizer.encode(report_text)
        elif callable(tokenizer):
            out = tokenizer(report_text)
            if isinstance(out, dict) and "input_ids" in out:
                ids = out["input_ids"]
            else:
                ids = out
        else:
            ids = []

        if isinstance(ids, torch.Tensor):
            ids = ids.detach().cpu().tolist()
        if not isinstance(ids, list):
            try:
                ids = list(ids)
            except Exception:
                ids = []

        ids = ids[: self.max_seq_length]
        if len(ids) < self.max_seq_length:
            ids = ids + [self.pad_idx] * (self.max_seq_length - len(ids))
        return torch.tensor(ids, dtype=torch.long, device=device)

    def _maybe_debug_print(
        self,
        sample_id: str,
        retrieved_ids: List[str],
        retrieved_texts: List[str],
        token_ids_batch: Optional[torch.Tensor] = None,
        missing_cnt: int = 0,
    ) -> None:
        if not self.debug or self._debug_print_left <= 0:
            return

        if dist is not None and hasattr(dist, "is_initialized") and dist.is_initialized():
            try:
                if dist.get_rank() != 0:
                    return
            except Exception:
                pass

        self._debug_print_left -= 1

        def _short(s: str) -> str:
            s = (s or "").replace("\n", " ").replace("\t", " ")
            s = " ".join(s.split())
            return s[: self.debug_max_chars]

        print("[RADAR][debug] sample_id:", str(sample_id))
        print("[RADAR][debug] retrieved_ids:", [str(x) for x in retrieved_ids])
        if retrieved_texts:
            print("[RADAR][debug] evidence_text[0]:", _short(retrieved_texts[0]))
        else:
            print("[RADAR][debug] evidence_text[0]: <EMPTY LIST>")

        if missing_cnt > 0:
            print(f"[RADAR][debug] WARNING: {missing_cnt}/{len(retrieved_ids)} retrieved ids not found in annotation mapping.")

        empty_cnt = sum(1 for t in retrieved_texts if not (t and t.strip()))
        if empty_cnt > 0:
            print(f"[RADAR][debug] WARNING: {empty_cnt}/{len(retrieved_texts)} retrieved texts are empty.")

        if token_ids_batch is not None:
            try:
                print("[RADAR][debug] token_ids shape:", tuple(token_ids_batch.shape))
                flat = token_ids_batch[0, 0, :10].detach().cpu().tolist()
                print("[RADAR][debug] token_ids[0,0,:10]:", flat)
            except Exception:
                pass

    def forward(self, sample_ids: List[str], split: str, tokenizer, device: torch.device) -> torch.Tensor:
        # NOTE: keep signature for compatibility; retrieval index itself is split-agnostic here.
        B = len(sample_ids)
        topk = self.topk

        all_token_ids: List[torch.Tensor] = []
        dbg_sid0 = str(sample_ids[0]) if B > 0 else None
        dbg_rids0: List[str] = []
        dbg_texts0: List[str] = []
        dbg_missing0: int = 0

        for sid in sample_ids:
            retrieved_ids = self.index.get(str(sid), topk=topk)
            if len(retrieved_ids) < topk:
                retrieved_ids = retrieved_ids + [str(sid)] * (topk - len(retrieved_ids))

            if dbg_sid0 is not None and str(sid) == dbg_sid0:
                dbg_rids0 = list(retrieved_ids)

            sid_token_ids: List[torch.Tensor] = []
            missing_cnt = 0

            for rid in retrieved_ids:
                rep = self.bank.get_report(str(rid))
                if str(rid) not in self.bank.id2report:
                    missing_cnt += 1

                if dbg_sid0 is not None and str(sid) == dbg_sid0:
                    dbg_texts0.append(rep)

                token_ids = self._encode_report_with_project_tokenizer(tokenizer, rep, device=device)
                sid_token_ids.append(token_ids)

            if dbg_sid0 is not None and str(sid) == dbg_sid0:
                dbg_missing0 = missing_cnt

            all_token_ids.append(torch.stack(sid_token_ids, dim=0))

        token_ids_batch = torch.stack(all_token_ids, dim=0)  # [B, topk, L]
        if dbg_sid0 is not None:
            self._maybe_debug_print(dbg_sid0, dbg_rids0, dbg_texts0, token_ids_batch, missing_cnt=dbg_missing0)

        B2, K, L = token_ids_batch.shape
        if B2 != B or K != topk or L != self.max_seq_length:
            raise RuntimeError(f"[RadarKnowledgeRetriever] token_ids shape unexpected: {token_ids_batch.shape}")

        token_ids_flat = token_ids_batch.reshape(B * topk, L)
        emb = self.text_embed(token_ids_flat)  # [B*topk, L, D]
        D = emb.size(-1)
        emb = emb.reshape(B, topk, L, D)

        mask = (token_ids_batch != self.pad_idx).float()
        mask_sum = mask.sum(dim=-1, keepdim=True).clamp(min=1.0)

        emb = emb * mask.unsqueeze(-1)
        pooled = emb.sum(dim=2) / mask_sum
        return pooled
