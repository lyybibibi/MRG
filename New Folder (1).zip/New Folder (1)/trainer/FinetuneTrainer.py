import pandas as pd
from .BaseTrainer import BaseTrainer
import numpy as np
import torch
import time
from utils.loss import patchify
import os
from tqdm import tqdm

# [WANDB] optional import
try:
    import wandb

    _WANDB_AVAILABLE = True
except Exception:
    wandb = None
    _WANDB_AVAILABLE = False


class Trainer(BaseTrainer):
    def __init__(self, model, criterion, metric_ftns, optimizer, args, lr_scheduler, train_dataloader, val_dataloader,
                 test_dataloader):
        super(Trainer, self).__init__(model, criterion, metric_ftns, optimizer, args)
        self.lr_scheduler = lr_scheduler
        self.train_dataloader = train_dataloader
        self.val_dataloader = val_dataloader
        self.test_dataloader = test_dataloader
        self.best_score = 0.

        # Load pretrained model if specified (usually for initialization)
        if args.get("load_model_path", ""):
            print(f"Loading pretrained model from {args['load_model_path']}")
            try:
                state = torch.load(args["load_model_path"], map_location='cuda')
                if 'state_dict' in state:
                    self.model.load_state_dict(state['state_dict'], strict=False)
                else:
                    self.model.load_state_dict(state, strict=False)
            except Exception as e:
                print(f"Warning: Failed to load pretrained model: {e}")

    def _train_epoch(self, epoch):
        # ---------------------------------------------------------
        # 1. Training Phase
        # ---------------------------------------------------------
        train_loss = 0
        self.model.train()

        # Training Progress Bar
        pbar = tqdm(enumerate(self.train_dataloader), total=len(self.train_dataloader), desc=f"Epoch {epoch} Training")

        for batch_idx, (images_id, images, reports_ids, reports_masks) in pbar:
            images, reports_ids, reports_masks = images.cuda(), reports_ids.cuda(), reports_masks.cuda()

            self.optimizer.zero_grad()

            # Forward (pass epoch for Warmup)
            output = self.model(images, reports_ids, mode='train', epoch=epoch, sample_ids=images_id, split='train')

            # Calculate Loss
            loss = self.criterion(output, reports_ids, reports_masks)
            loss.backward()

            # Clip Gradients
            torch.nn.utils.clip_grad_value_(self.model.parameters(), 0.1)
            self.optimizer.step()

            train_loss += loss.item()
            pbar.set_postfix({'loss': loss.item()})

        log = {'train_loss': train_loss / len(self.train_dataloader)}

        # ---------------------------------------------------------
        # 2. Validation Phase
        # ---------------------------------------------------------
        self.model.eval()
        with torch.no_grad():
            val_gts, val_res = [], []
            val_pbar = tqdm(enumerate(self.val_dataloader), total=len(self.val_dataloader),
                            desc=f"Epoch {epoch} Validation")

            for batch_idx, (images_id, images, reports_ids, reports_masks) in val_pbar:
                images = images.cuda()
                reports_ids = reports_ids.cuda()

                # Beam Search Inference
                output = self.model(images, mode='sample', sample_ids=images_id, split='val')

                # Decode Token IDs to Text
                reports = self.model.tokenizer.decode_batch(output.cpu().numpy())
                ground_truths = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())

                val_res.extend(reports)
                val_gts.extend(ground_truths)

            # Compute Metrics (BLEU, METEOR, ROUGE, CIDEr)
            val_met = self.metric_ftns({i: [gt] for i, gt in enumerate(val_gts)},
                                       {i: [re] for i, re in enumerate(val_res)})

            # Update log with val metrics
            log.update(**{'val_' + k: v for k, v in val_met.items()})

        # ---------------------------------------------------------
        # 3. Scheduler Step
        # ---------------------------------------------------------
        if self.lr_scheduler is not None:
            self.lr_scheduler.step()

        # ---------------------------------------------------------
        # 4. Test Phase (Optional, but often useful to log test metrics too)
        # ---------------------------------------------------------
        if hasattr(self, 'test_dataloader') and self.test_dataloader is not None:
            self.model.eval()
            test_gts, test_res = [], []  # Reset lists

            # 【核心修复】：增加 images_id 解包，并加上 tqdm
            test_pbar = tqdm(enumerate(self.test_dataloader), total=len(self.test_dataloader),
                             desc=f"Epoch {epoch} Test")

            with torch.no_grad():
                for batch_idx, (images_id, images, reports_ids, reports_masks) in test_pbar:
                    images = images.cuda()  # Ensure device consistency
                    reports_ids = reports_ids.cuda()

                    output = self.model(images, mode='sample', sample_ids=images_id, split='test')

                    decoded_out = self.model.tokenizer.decode_batch(output.cpu().numpy())
                    decoded_gts = self.model.tokenizer.decode_batch(reports_ids[:, 1:].cpu().numpy())

                    test_res.extend(decoded_out)
                    test_gts.extend(decoded_gts)

                test_scores = self.metric_ftns({i: [gt] for i, gt in enumerate(test_gts)},
                                               {i: [re] for i, re in enumerate(test_res)})

                # Update log with test metrics
                for k, v in test_scores.items():
                    log[f'test_{k}'] = v

        return log