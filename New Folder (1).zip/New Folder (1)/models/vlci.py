import torch
import torch.nn as nn
import torch.nn.functional as F
from modules.modules4vlp import get_ht_mask, get_hv_mask, get_cross_mask
from modules.modules4transformer import LayerNorm, Encoder, DecoderLayer, EncoderLayer
from models.baseline import Baseline
from utils import tensor_utils
from modules.modules4vlci import LDM, LocalSample, GlobalSample, VDM
from modules.knowledge_retriever_radar import RadarKnowledgeRetriever


# =============================================================================
# 1. CausalEncoder
# =============================================================================
class CausalEncoder(nn.Module):
    def __init__(self, embed_dim, num_layer, num_heads, ff_dim, dropout, mode='none', stitch=None):
        super(CausalEncoder, self).__init__()
        self.mode = mode
        self.layers = nn.ModuleList(
            [EncoderLayer(embed_dim, num_heads, ff_dim, dropout) for _ in range(num_layer)])

        stitch = stitch or {}

        self.local_sample = LocalSample(
            embed_dim=embed_dim,
            num_heads=num_heads,
            ff_dim=ff_dim,
            dropout=dropout,
            use_cmqfl=stitch.get("use_cmqfl", False),
            cmqfl_num_query_token=stitch.get("cmqfl_num_query_token", 6),
            cmqfl_vision_width=stitch.get("cmqfl_vision_width", None),
            cmqfl_cross_attention_freq=stitch.get("cmqfl_cross_attention_freq", 2),
            cmqfl_freeze=stitch.get("cmqfl_freeze", True),
            cmqfl_fuse=stitch.get("cmqfl_fuse", "replace"),
            cmqfl_use_caam=stitch.get("cmqfl_use_caam", True),
        )

        self.global_sample = GlobalSample(embed_dim, num_heads, ff_dim, dropout)

        self.do = VDM(embed_dim, num_heads, ff_dim, dropout)
        self.norm = LayerNorm(embed_dim)

    def forward(self, h, mask=None, proj=False):
        attn_list = []
        for layer in self.layers:
            h, attn = layer(h, mask, return_attn=True)
            attn_list.append(attn)

        fl = self.local_sample(h, attn_list, 6)
        fg = self.global_sample(h)

        mediator = {"local": fl, "global": fg}

        h = self.do(h, fl=fl, fg=fg, mode=self.mode, proj=proj)
        h = self.norm(h)

        return h, mediator


# =============================================================================
# 2. RADARRetriever
# =============================================================================
class RADARRetriever(nn.Module):
    def __init__(self, embed_dim, memory_size=1000, num_classes=14):
        super(RADARRetriever, self).__init__()
        self.observation_head = nn.Sequential(
            nn.Linear(embed_dim, embed_dim // 2),
            nn.ReLU(),
            nn.Linear(embed_dim // 2, num_classes)
        )
        self.register_buffer('memory_logits', torch.randn(memory_size, num_classes))
        self.register_buffer('memory_knowledge', torch.randn(memory_size, 3, embed_dim))
        self.proj = nn.Linear(embed_dim, embed_dim)

    def forward(self, visual_cls):
        B = visual_cls.size(0)
        curr_logits = self.observation_head(visual_cls)
        curr_probs = torch.sigmoid(curr_logits)

        curr_norm = F.normalize(curr_probs, p=2, dim=1)
        mem_norm = F.normalize(torch.sigmoid(self.memory_logits), p=2, dim=1)

        scores = torch.mm(curr_norm, mem_norm.t())
        _, topk_indices = torch.topk(scores, k=3, dim=1)

        k_emb = self.memory_knowledge[topk_indices]
        k_emb = k_emb.view(B, -1, k_emb.size(-1))

        return self.proj(k_emb)


# =============================================================================
# 3. CausalDecoder
# =============================================================================
from modules.evidence_calibration import RCSFilter, VocabularyDebiasing


# =============================================================================
# 重构后的 CausalDecoder (剔除错误的特征减法干预)
# =============================================================================
class CausalDecoder(nn.Module):
    def __init__(self, embed_dim, num_layer, num_heads, ff_dim, dropout, mode='none', stitch=None):
        super(CausalDecoder, self).__init__()
        self.mode = mode
        self.norm = LayerNorm(embed_dim)
        self.do = LDM(embed_dim)

        self.layers = nn.ModuleList(
            [DecoderLayer(embed_dim, num_heads, ff_dim, dropout) for _ in range(num_layer)])
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            torch.nn.init.xavier_uniform_(m.weight)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)

    def forward(self, output, h, self_mask=None, cross_mask=None, z=None, fl=None, proj=False):
        # Standard Decoding
        for layer in self.layers:
            output = layer(output, h, self_mask, cross_mask)

        # Linguistic Deconfounding (LDM)
        output = self.do(output, z, fl, self.mode, proj=proj)
        output = self.norm(output)
        return output


# =============================================================================
# 重构后的 VLCI Main Class (串联 RCS 与 偏置校准)
# =============================================================================
class VLCI(Baseline):
    def __init__(self, args, tokenizer):
        super(VLCI, self).__init__(args, tokenizer)

        # 移除引发噪声的随机 retriever fallback
        self.radar_retriever = None
        self.radar_train_retriever = None
        self.radar_val_retriever = None
        self.radar_test_retriever = None

        # 挂载新机制模块
        self.rcs_filter = RCSFilter(temperature=0.1, retrieve_threshold=args.get('rcs_threshold', 2.0))
        self.vocab_debias = VocabularyDebiasing(embed_dim=self.embed_dim, vocab_size=self.vocab_size + 1,
                                                dropout=self.dropout)

        stitch_cfg = args.get('stitch', {}) if isinstance(args, dict) else {}
        radar_use = bool(stitch_cfg.get('radar_use', args.get('radar_use', False) if isinstance(args, dict) else False))

        if radar_use:
            # (保留你原有的雷达离线加载逻辑)
            ann_path = stitch_cfg.get('radar_ann_path', args.get('radar_ann_path', args.get('ann_path', None)))
            topk = int(stitch_cfg.get('radar_topk', args.get('radar_topk', 4)))
            train_jsonl = stitch_cfg.get('radar_train_jsonl', args.get('radar_train_jsonl', None))
            val_jsonl = stitch_cfg.get('radar_val_jsonl', args.get('radar_val_jsonl', None))
            test_jsonl = stitch_cfg.get('radar_test_jsonl', args.get('radar_test_jsonl', None))

            if ann_path and train_jsonl:
                self.radar_train_retriever = RadarKnowledgeRetriever(
                    knowledge_jsonl_path=train_jsonl, ann_path=ann_path, text_embed=self.text_embed,
                    max_seq_length=args.get('max_seq_length', 60), pad_idx=args.get('pad_idx', 0), topk=topk)
            if ann_path and val_jsonl:
                self.radar_val_retriever = RadarKnowledgeRetriever(
                    knowledge_jsonl_path=val_jsonl, ann_path=ann_path, text_embed=self.text_embed,
                    max_seq_length=args.get('max_seq_length', 60), pad_idx=args.get('pad_idx', 0), topk=topk)
            if ann_path and test_jsonl:
                self.radar_test_retriever = RadarKnowledgeRetriever(
                    knowledge_jsonl_path=test_jsonl, ann_path=ann_path, text_embed=self.text_embed,
                    max_seq_length=args.get('max_seq_length', 60), pad_idx=args.get('pad_idx', 0), topk=topk)

        self.encoder = CausalEncoder(
            embed_dim=self.embed_dim, num_layer=self.en_num_layers, num_heads=self.num_heads,
            ff_dim=self.ff_dim, dropout=self.dropout, mode=args["v_causal"], stitch=stitch_cfg
        )

        self.decoder = CausalDecoder(
            embed_dim=self.embed_dim, num_layer=self.de_num_layers, num_heads=self.num_heads,
            ff_dim=self.ff_dim, dropout=self.dropout, mode=args["l_causal"]
        )
        self.register_buffer('vocab_indices', torch.arange(self.vocab_size + 1))

    def _get_custom_logit_fn(self, k_filtered_emb):
        """为Beam Search包装动态Logit映射函数"""

        def custom_logit(out):
            # 双重保险：强制约束时间步序列维度为 1
            if out.dim() == 3 and out.size(1) > 1:
                out = out[:, -1:]

            logits = self.logit(out)
            if k_filtered_emb is not None:
                if k_filtered_emb.size(0) != logits.size(0):
                    beam_size = logits.size(0) // k_filtered_emb.size(0)
                    k_exp = tensor_utils.tile(k_filtered_emb, beam_size, 0)
                else:
                    k_exp = k_filtered_emb
                logits = self.vocab_debias(logits, k_exp)
            return logits

        return custom_logit

    def _forward(self, hv, targets, mode, B, epoch=None, **kwargs):
        # 1. Vision Encode (去偏提取)
        hv = hv.reshape([B, -1, self.embed_dim])
        cls_token = self.cls_token + self.vis_embed.pos_embed[:, :1, :]
        hv = torch.cat((cls_token.expand(hv.shape[0], -1, -1), hv), dim=1)

        hv_mask = get_hv_mask(hv)
        hv, mediator = self.encoder(hv, hv_mask)
        h_pooled = hv[:, 0, :]  # 获取去偏后的纯净特征h

        # 2. RAG & RCS (因果导向在线检索与自适应过滤)
        k = None
        k_filtered_emb = None
        sample_ids = kwargs.get('sample_ids', None)
        split = kwargs.get('split', 'train' if mode == 'train' else 'val')

        _rk = None
        if str(split) == 'train':
            _rk = self.radar_train_retriever
        elif str(split) == 'val':
            _rk = self.radar_val_retriever
        elif str(split) == 'test':
            _rk = self.radar_test_retriever

        if _rk is not None and sample_ids is not None:
            sample_ids_list = [str(x) for x in sample_ids] if isinstance(sample_ids, (tuple, list)) else [
                str(sample_ids)]
            k = _rk(sample_ids=sample_ids_list, split=str(split), tokenizer=self.tokenizer,
                    device=hv.device)  # [B, K, D]

            # RCS 动态过滤
            mask, _ = self.rcs_filter(h_pooled, k)

            # 聚合保留的有效证据
            valid_k = k * mask.unsqueeze(-1)
            k_filtered_emb = valid_k.sum(dim=1) / mask.sum(dim=1, keepdim=True).clamp(min=1)  # [B, D]

        self.z = self.text_embed.embed(self.vocab_indices.unsqueeze(0))

        if mode == 'train':
            z_expanded = self.z.expand(B, -1, -1)
            ht_mask, targets = get_ht_mask(targets)
            ht = self.text_embed(targets)

            out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=hv_mask,
                               z=z_expanded, fl=mediator.get('local', None))

            # 3. 分布偏置校准 (LDM之后)
            logits = self.logit(out)
            if k_filtered_emb is not None:
                logits = self.vocab_debias(logits, k_filtered_emb)

            outputs = [F.log_softmax(logits, dim=-1)]
            return outputs

        elif mode == 'sample':
            # 将带有偏置注入的Logit计算逻辑注入到Beam Search
            logit_fn = self._get_custom_logit_fn(k_filtered_emb)
            self.beam_search.load_model(
                lambda *args: self.sample_forward(*args, fl=mediator.get('local', None)),
                logit_fn
            )
            outputs, _ = self.beam_search.sample_beam(hv, hv_mask)
            self.beam_search.clean_model()
            return outputs

    def sample_forward(self, hv, ht, hv_mask, ht_mask, fl=None):
        ht_ids = ht
        ht = self.text_embed(ht)
        current_bs = ht.size(0)

        # 1. 检查主视觉特征是否需要膨胀 (Beam Search 内部通常已处理)
        if hv.size(0) != current_bs:
            beam_size = current_bs // hv.size(0)
            hv = tensor_utils.tile(hv, beam_size, 0)
            if hv_mask is not None: hv_mask = tensor_utils.tile(hv_mask, beam_size, 0)

        # 2. 【核心修复】独立检查并膨胀外部传入的 fl (mediator)
        if fl is not None and fl.size(0) != current_bs:
            beam_size = current_bs // fl.size(0)
            fl = tensor_utils.tile(fl, beam_size, 0)

        if not hasattr(self, 'z'): self.z = self.text_embed.embed(self.vocab_indices.unsqueeze(0))
        z_expanded = self.z.expand(current_bs, -1, -1)

        seq_len = ht_ids.size(1)
        hv_len = hv.size(1)
        if hv_mask is None:
            cross_mask = hv.new_ones((current_bs, seq_len, hv_len), dtype=torch.long)
        else:
            if hv_mask.dim() == 4: hv_mask = hv_mask.squeeze(-2)
            if hv_mask.dim() == 3 and hv_mask.size(1) == 1:
                cross_mask = hv_mask.expand(current_bs, seq_len, hv_len)
            elif hv_mask.dim() == 3 and hv_mask.size(1) == seq_len:
                cross_mask = hv_mask
            else:
                cross_mask = hv.new_ones((current_bs, seq_len, hv_len), dtype=torch.long)

        out = self.decoder(ht, hv, self_mask=ht_mask, cross_mask=cross_mask, fl=fl, z=z_expanded)

        # 【核心修复】：自回归生成时，只保留最后一个时间步的特征
        return out[:, -1:]
